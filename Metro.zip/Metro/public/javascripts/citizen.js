class Citizen {
	constructor(stationVector) {

		// Define
		this.name = firstNames[Math.floor(Math.random() * firstNames.length)] + ' ' + lastNames[Math.floor(Math.random() * lastNames.length)]
		this.id = randomString(20);

		// Position
		var randomCitizenSpawn = new Vector(Math.floor(Math.random() * 75), -Math.floor(Math.random() * 100));
		if(Math.floor(Math.random() * 2) == 1) {
			randomCitizenSpawn.x = -randomCitizenSpawn.x;
		}
		this.pos = new Vector(stationVector.x + randomCitizenSpawn.x, stationVector.y + randomCitizenSpawn.y);

		// Citizen AI
		this.objective = undefined;
		this.objectiveName = undefined;
		this.path = undefined;
		this.target = undefined;

		// Drawing
		this.opacity = 0;

		// Emotion
		this.experience = undefined;
		this.startTime = undefined;
		this.endTime = undefined;
		this.originStation = new Vector(stationVector.x+25, stationVector.y+25);
		this.endStation = undefined;

		// Boarding
		this.boarding = false;
		this.arrived = false;

	}
}

function citizenObjective() {
	if(stations.length > 1) {
		for (var i = 0; i < stations.length; i++) {
			for (var j = 0; j < stations[i].citizenDeparture.length; j++) {
				if(stations[i].citizenDeparture[j].objective == undefined) {
					var randomStation = Math.floor(Math.random() * stations.length);
					stations[i].citizenDeparture[j].objective = stations[randomStation].id;
					stations[i].citizenDeparture[j].objectiveName = stations[randomStation].name;
					while(stations[i].citizenDeparture[j].objective == stations[i].id) {
						var randomStation = Math.floor(Math.random() * stations.length);
						stations[i].citizenDeparture[j].objective = stations[randomStation].id;
						stations[i].citizenDeparture[j].objectiveName = stations[randomStation].name;
					}
				}
			}
		}
	}
}


function citizenUpdate() {
	for (var i = 0; i < stations.length; i++) {
		for (var j = 0; j < stations[i].citizenDeparture.length; j++) {
			if(stations[i].citizenDeparture[j].pos.y != stations[i].citizenDeparture[j].target.y.toFixed(0)) {
				if(stations[i].citizenDeparture[j].pos.y > stations[i].citizenDeparture[j].target.y.toFixed(0)) {
					stations[i].citizenDeparture[j].pos.y -= 0.5;
				} else {
					stations[i].citizenDeparture[j].pos.y += 0.5;
				}
			} else if(stations[i].citizenDeparture[j].pos.x != stations[i].citizenDeparture[j].target.x.toFixed(0)) {
				if(stations[i].citizenDeparture[j].pos.x > stations[i].citizenDeparture[j].target.x.toFixed(0)) {
					stations[i].citizenDeparture[j].pos.x -= 0.5;
				} else {
					stations[i].citizenDeparture[j].pos.x += 0.5;
				}
			} else {
				if(stations[i].citizenDeparture[j].startTime == undefined) {
					stations[i].citizenDeparture[j].startTime = totalTime;
				}
			}
		}
		for (var k = 0; k < stations[i].citizenArrival.length; k++) {
			if(!stations[i].citizenArrival[k].arrived) {
				if(Math.floor(Math.random() * 50) === 1) {
					var randomArrival = 5 + Math.floor(Math.random() * 15);
					stations[i].citizenArrival[k].pos = new Vector(stations[i].pos.x, stations[i].pos.y+randomArrival);
					stations[i].citizenArrival[k].target = new Vector(stations[i].pos.x - 55, stations[i].pos.y+randomArrival);
					stations[i].citizenArrival[k].arrived = true;
				}
			} else {
				if(stations[i].citizenArrival[k].opacity > 0.01) {
					stations[i].citizenArrival[k].opacity -= 0.01;
				} else {
					stations[i].citizenArrival[k].opacity = 0;	
				}
				if(stations[i].citizenArrival[k].pos.x != stations[i].citizenArrival[k].target.x.toFixed(0)) {
					if(stations[i].citizenArrival[k].pos.x > stations[i].citizenArrival[k].target.x.toFixed(0)) {
						stations[i].citizenArrival[k].pos.x -= 0.5;
					} else {
						stations[i].citizenArrival[k].pos.x += 0.5;
					}
				}
				if(stations[i].citizenArrival[k].opacity == 0 && stations[i].citizenArrival[k].pos.x-2 < stations[i].citizenArrival[k].target.x && stations[i].citizenArrival[k].target.x < stations[i].citizenArrival[k].pos.x+2 && stations[i].citizenArrival[k].pos.y-2 < stations[i].citizenArrival[k].target.y && stations[i].citizenArrival[k].target.y < stations[i].citizenArrival[k].pos.y+2) {
					var xDist = stations[i].citizenArrival[k].endStation.x - stations[i].citizenArrival[k].originStation.x;
					var yDist = stations[i].citizenArrival[k].endStation.y - stations[i].citizenArrival[k].originStation.y;
				 	var currentLine = Math.sqrt(xDist * xDist + yDist * yDist);
					var minTime = (currentLine / 3);

					if((stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) < minTime+1800) {
						ratings[0] += 1;
						if(rating20.length > 20) {
							rating20.splice(1, 1);
						}
						rating20.push(5);
					} else if((stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) < minTime+3600 && (stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) > minTime+1800) {
						ratings[1] += 1;
						if(rating20.length > 20) {
							rating20.splice(1, 1);
						}
						rating20.push(4)
					} else if((stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) < minTime+7200 && (stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) > minTime+3600) {
						ratings[2] += 1;
						if(rating20.length > 20) {
							rating20.splice(1, 1);
						}
						rating20.push(3)
					} else if((stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) < minTime+14400 && (stations[i].citizenArrival[k].endTime - stations[i].citizenArrival[k].startTime) > minTime+7200) {
						ratings[3] += 1;
						if(rating20.length > 20) {
							rating20.splice(1, 1);
						}
						rating20.push(2)
					} else {
						ratings[4] += 1;
						if(rating20.length > 20) {
							rating20.splice(1, 1);
						}
						rating20.push(1)
					}
					stations[i].citizenArrival.splice(k, 1);
					bankBalance += 2;
					
				}
			}
		}
	}
}

setInterval(function() {
		for (var i = 0; i < stations.length; i++) { 
			if(Math.floor(Math.random() * 10) == 1) {
				stations[i].citizenDeparture.push(new Citizen(stations[i].pos));
			}
		}
	
}, 200)

function randomSpawnRadius() {
	
	return randomCitizenSpawn;
}

function randomString(length) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');

    if (! length) {
        length = Math.floor(Math.random() * chars.length);
    }

    var str = '';
    for (var i = 0; i < length; i++) {
        str += chars[Math.floor(Math.random() * chars.length)];
    }
    return str;
}