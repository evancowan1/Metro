class Line {
	constructor(type, path, connected, vehicles, connectedPath) {

		this.id = randomString(10);

		this.lineType = type;
		this.linePath = path;

		this.vehicles = vehicles;
		this.connections = connected;
		this.connectedPath = connectedPath;

	}
}

var newLine = [];
var connected = [];
var connectedPath = [0];
var clickOverride = true;
var placeToggle = false;
var placeMode = false;
function linePlace() {

	if (eventInput[49]) { // 1
		if(placeToggle === false) {
			placeToggle = true;
			placeMode = !placeMode;
		}
	} else {
		if (placeToggle) {
			placeToggle = false;

		}
	}

	if(placeMode) {
		var x = ((Math.ceil(((mouse.x-canvas.width/2)/rectHeightRel+camera.pos.x) / 25) * 25)-25)*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel;
		var y = ((Math.ceil(((mouse.y-canvas.height/2)/rectHeightRel+camera.pos.y) / 25) * 25)-25)*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel;
		var world = new Vector(((Math.ceil(((mouse.x-canvas.width/2)/rectHeightRel+camera.pos.x) / 25) * 25)-25), ((Math.ceil(((mouse.y-canvas.height/2)/rectHeightRel+camera.pos.y) / 25) * 25)-25))
		
		var showPointer = 0;
		for (var i = 0; i < stations.length; i++) {
			if(world.x == stations[i].pos.x && world.y == stations[i].pos.y) {
				showPointer = 1;
			}
			if(world.x == stations[i].pos.x+25 && world.y == stations[i].pos.y) {
				showPointer = 2;
			}
		}

		if(showPointer == 0) {
			ctx.beginPath();
			ctx.fillStyle = 'green';
			ctx.globalAlpha = 1;
			ctx.arc(x+(25/2)*rectHeightRel, y+(25/2)*rectHeightRel, (25/3)*rectHeightRel, 0, 2 * Math.PI);
			ctx.fill();
			ctx.closePath();
		} else if(showPointer == 1) {
			ctx.beginPath();
			ctx.fillStyle = 'green';
			ctx.globalAlpha = 0.5;
			ctx.fillRect(world.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, world.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel, 50*rectHeightRel, 25*rectHeightRel);
			ctx.closePath();
		} else if(showPointer == 2) {
			ctx.beginPath();
			ctx.fillStyle = 'green';
			ctx.globalAlpha = 0.5;
			ctx.fillRect((world.x-25)*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, world.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel, 50*rectHeightRel, 25*rectHeightRel);
			ctx.closePath();
		}

		if(newLine.length > 0) {
			ctx.beginPath();
			ctx.lineCap = "round";
			ctx.lineWidth = 7*rectHeightRel;
			ctx.fillStyle = 'green';
			ctx.globalAlpha = 0.5;
			ctx.moveTo(newLine[0].x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (25/2)*rectHeightRel, newLine[0].y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + (25/2)*rectHeightRel);
			for (var i = 1; i < newLine.length; i++) {
				ctx.lineTo(newLine[i].x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (25/2)*rectHeightRel, newLine[i].y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + (25/2)*rectHeightRel);
			}
			ctx.lineTo(x + (25/2)*rectHeightRel, y + (25/2)*rectHeightRel);
			ctx.stroke();
			ctx.closePath();
		}

		if(mouseDown) {
			var place = true;
			if(place && clickOverride) {
				var obstruction = false;
				var activeStation = false;
				if(newLine.length < 1) {
					for (var i = 0; i < stations.length; i++) {
						if((world.x == stations[i].pos.x+25 && world.y == stations[i].pos.y) || (world.x == stations[i].pos.x && world.y == stations[i].pos.y)) {
							connected.push(stations[i].id);
							newLine.push(new Vector((stations[i].pos.x + 25/2), (stations[i].pos.y+25)));
						}
					}
				} else {
					for (var i = 0; i < stations.length; i++) {
						if((world.x == stations[i].pos.x+25 && world.y == stations[i].pos.y) || (world.x == stations[i].pos.x && world.y == stations[i].pos.y)) {
							if((world.x+25/2 == newLine[0].x && world.y+25 == newLine[0].y) || (world.x-25+25/2 == newLine[0].x && world.y+25 == newLine[0].y) && newLine.length > 2) {
								lines.push(new Line('bus', newLine, connected, [new Vehicle(), new Vehicle()], connectedPath));
								for (var j = 0; j < stations.length; j++) {
									if(connected.includes(stations[j].id)) {
										for (var k = 0; k < connected.length; k++) {
											if(connected[k] != stations[j].id) {
												stations[j].connections.push(connected[k]);
											}
										}
									}
								}
								connectedPath = [0];
								connected = [];
								newLine = [];
							} else {
								connected.push(stations[i].id);
								newLine.push(new Vector((stations[i].pos.x + 25/2), (stations[i].pos.y+25)));
								connectedPath.push(newLine.length-1);
							}
							activeStation = true;
						}
					}
					if(!activeStation) {
						for (var i = 0; i < newLine.length; i++) {
							if(world.x == newLine[i].x && world.y == newLine[i].y) {
								obstruction = true;
							}
						}
						if(!obstruction) {
							newLine.push(world);
						}
					}
				}
			}
			var place = false;
			clickOverride = false;
		}

		if(!mouseDown) {
			clickOverride = true;
		}
	} else {
		newLine = [];
		connected = [];
	}
}