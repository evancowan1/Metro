class Vehicle {
	constructor() {

		this.pos = new Vector(Infinity, Infinity);;
		this.target = new Vector(Infinity, Infinity);

		this.id = randomString(12);

		this.capacity = 50;
		this.hosting = 0;
		this.pathTarget = 1;
		this.speed = 3;

		this.rotation = 0;
		this.citizens = [];
		this.connections = [];


		// Boarding
		this.inTransit = true;
		this.boarding = false;
		this.stoppedStation = undefined;
		this.stoppedID = undefined;
		this.stationBoarded = false;
		this.previousBoarded = 0;
		this.disembark = false;
		this.boardingCycle = 0;

		//Line
		this.currentLine = 0;
		this.percentageEnd = 0;
		this.percentageStart = 0;
		this.minTime = 0;
		this.startTime = totalTime;
		this.segmentTime = 0;

	}
}

function vehicleUpdate() {

	for (var i = 0; i < lines.length; i++) {
		for (var j = 0; j < lines[i].vehicles.length; j++) {
			for (var k = 0; k < lines[i].vehicles[j].citizens.length; k++) {
				lines[i].vehicles[j].citizens.pos = lines[i].vehicles[j].pos.copy();
			}
		}
	}

	for (var i = 0; i < lines.length; i++) {
		for (var j = 0; j < lines[i].vehicles.length; j++) {
			if(lines[i].vehicles[j].pathTarget === 0) {
				var xDist = lines[i].linePath[lines[i].linePath.length-1].x - lines[i].linePath[lines[i].vehicles[j].pathTarget].x;
				var yDist = lines[i].linePath[lines[i].linePath.length-1].y - lines[i].linePath[lines[i].vehicles[j].pathTarget].y;
			} else {
				var xDist = lines[i].linePath[lines[i].vehicles[j].pathTarget-1].x - lines[i].linePath[lines[i].vehicles[j].pathTarget].x;
				var yDist = lines[i].linePath[lines[i].vehicles[j].pathTarget-1].y - lines[i].linePath[lines[i].vehicles[j].pathTarget].y;
			}
			var xDistLine = lines[i].linePath[lines[i].vehicles[j].pathTarget].x - lines[i].vehicles[j].pos.x;
			var yDistLine = lines[i].linePath[lines[i].vehicles[j].pathTarget].y - lines[i].vehicles[j].pos.y;
			lines[i].vehicles[j].currentLine = Math.sqrt(xDist * xDist + yDist * yDist);
			var distLine = Math.sqrt(xDistLine * xDistLine + yDistLine * yDistLine);
			lines[i].vehicles[j].percentageStart = distLine / lines[i].vehicles[j].currentLine;			
			lines[i].vehicles[j].percentageEnd = 1 - lines[i].vehicles[j].percentageStart;
			lines[i].vehicles[j].minTime = lines[i].vehicles[j].currentLine / 3;
		}
	}

	// Moving
	for (var i = 0; i < lines.length; i++) {
		for (var j = 0; j < lines[i].vehicles.length; j++) {
			if(lines[i].vehicles[j].pos.x == Infinity && lines[i].vehicles[j].pos.y == Infinity) {
				var firstPos = lines[i].linePath[0].copy();
				lines[i].vehicles[j].pos = firstPos;
				lines[i].vehicles[j].target = lines[i].linePath[lines[i].vehicles[j].pathTarget];
			} else {
				if(lines[i].vehicles[j].pos.x-2 < lines[i].vehicles[j].target.x && lines[i].vehicles[j].target.x < lines[i].vehicles[j].pos.x+2 && lines[i].vehicles[j].pos.y-2 < lines[i].vehicles[j].target.y && lines[i].vehicles[j].target.y < lines[i].vehicles[j].pos.y+2) {
					if(lines[i].vehicles[j].pathTarget < lines[i].linePath.length-1) {
						lines[i].vehicles[j].pathTarget += 1;	
					} else {
						lines[i].vehicles[j].pathTarget = 0;
					}
					lines[i].vehicles[j].target = lines[i].linePath[lines[i].vehicles[j].pathTarget];
					lines[i].vehicles[j].stationBoarded = false;
					lines[i].vehicles[j].segmentTime = totalTime - lines[i].vehicles[j].startTime;
					lines[i].vehicles[j].startTime = totalTime;

				}
				if(lines[i].connectedPath.includes(lines[i].vehicles[j].pathTarget)) {
					if(3*(3*lines[i].vehicles[j].percentageStart) < lines[i].vehicles[j].speed) {
						if(lines[i].vehicles[j].speed <= 0.5) {
							lines[i].vehicles[j].speed = 0.5;	
						} else {
							if(3 * (3*lines[i].vehicles[j].percentageStart) < 0.5) {
								lines[i].vehicles[j].speed = 0.5
							} else {
								lines[i].vehicles[j].speed = 3 * (3*lines[i].vehicles[j].percentageStart);
							}
						}
					} else {
						lines[i].vehicles[j].speed = 3;
					}
				} else {
					if(lines[i].vehicles[j].speed*(1+lines[i].vehicles[j].percentageEnd) > lines[i].vehicles[j].speed) {
						if(lines[i].vehicles[j].speed >= 3) {
							lines[i].vehicles[j].speed = 3;	
						} else {
							if(lines[i].vehicles[j].speed * (1+lines[i].vehicles[j].percentageEnd) > 3) {
								lines[i].vehicles[j].speed = 3;
							} else {
								lines[i].vehicles[j].speed = lines[i].vehicles[j].speed * (1+lines[i].vehicles[j].percentageEnd);
							}
						}
					} else {
						lines[i].vehicles[j].speed = 0.5;
					}
						
				}
				if(lines[i].connectedPath.includes(lines[i].vehicles[j].pathTarget-1)) {
					for (var k = 0; k < stations.length; k++) {
						if(stations[k].pos.x+(25/2) == lines[i].linePath[lines[i].vehicles[j].pathTarget-1].x && stations[k].pos.y+25 == lines[i].linePath[lines[i].vehicles[j].pathTarget-1].y) {
							lines[i].vehicles[j].stoppedStation = stations[k].id
							lines[i].vehicles[j].stoppedID = k;
						}
					}
					if(lines[i].vehicles[j].stationBoarded == false && !stations[lines[i].vehicles[j].stoppedID].arrival && lines[i].vehicles[j].pos.x-5 < stations[lines[i].vehicles[j].stoppedID].pos.x+(25/2) && stations[lines[i].vehicles[j].stoppedID].pos.x+(25/2) < lines[i].vehicles[j].pos.x+5 && lines[i].vehicles[j].pos.y-5 < stations[lines[i].vehicles[j].stoppedID].pos.y+25 && stations[lines[i].vehicles[j].stoppedID].pos.y+25 < lines[i].vehicles[j].pos.y+5) {
						lines[i].vehicles[j].inTransit = false;
						lines[i].vehicles[j].boarding = true;
						lines[i].vehicles[j].disembark = true;
						stations[lines[i].vehicles[j].stoppedID].arrival = true;
					}
				}
				if(lines[i].vehicles[j].inTransit) {
					lines[i].vehicles[j].boarding = false;
					lines[i].vehicles[j].disembark = false;
					lines[i].vehicles[j].rotation = Math.atan2(lines[i].vehicles[j].target.y - lines[i].vehicles[j].pos.y, lines[i].vehicles[j].target.x - lines[i].vehicles[j].pos.x);
					lines[i].vehicles[j].pos.x += Math.cos(lines[i].vehicles[j].rotation) * lines[i].vehicles[j].speed;
					lines[i].vehicles[j].pos.y += Math.sin(lines[i].vehicles[j].rotation) * lines[i].vehicles[j].speed;
				}
			}
		}
	}
}

function boarding() {
	for (var i = 0; i < lines.length; i++) {
		for (var j = 0; j < lines[i].vehicles.length; j++) {
			if(lines[i].vehicles[j].disembark) {
				for (var h = 0; h < lines[i].vehicles[j].citizens.length; h++) {
					if(lines[i].vehicles[j].citizens[h].objective == lines[i].vehicles[j].stoppedStation) {
						lines[i].vehicles[j].citizens[h].endTime = totalTime;
						lines[i].vehicles[j].citizens[h].endStation = new Vector(stations[lines[i].vehicles[j].stoppedID].pos.x+25, stations[lines[i].vehicles[j].stoppedID].pos.y+25);
						stations[lines[i].vehicles[j].stoppedID].citizenArrival.push(lines[i].vehicles[j].citizens[h]);
						lines[i].vehicles[j].citizens.splice(h, 1);
						lines[i].vehicles[j].hosting -= 1;
						lines[i].vehicles[j].previousBoarded -=1;
					}
				}
				lines[i].vehicles[j].stationBoarded = true;
				lines[i].vehicles[j].disembark = false;
				
			} else {
				if(lines[i].vehicles[j].hosting < lines[i].vehicles[j].capacity) {
					if(lines[i].vehicles[j].boarding) {
						for (var k = 0; k < stations[lines[i].vehicles[j].stoppedID].citizenDeparture.length; k++) {
							if(lines[i].vehicles[j].previousBoarded < lines[i].vehicles[j].capacity-1) {
								if(lines[i].connections.includes(stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].objective)) { //*****
									stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].target = new Vector(lines[i].vehicles[j].pos.x, lines[i].vehicles[j].pos.y)
									stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].boarding = true;
									lines[i].vehicles[j].previousBoarded += 1;
								}
							}
						}
						lines[i].vehicles[j].boarding = false;
						lines[i].vehicles[j].stationBoarded = true;
					}
				} else {
					lines[i].vehicles[j].boarding = false;
					lines[i].vehicles[j].stationBoarded = true;
				}

				//Loading
				if(lines[i].vehicles[j].hosting < lines[i].vehicles[j].capacity) {
					if(!lines[i].vehicles[j].inTransit) {
						for (var k = 0; k < stations[lines[i].vehicles[j].stoppedID].citizenDeparture.length; k++) {
							if(stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].pos.x.toFixed(0)-1 < lines[i].vehicles[j].pos.x.toFixed(0) && lines[i].vehicles[j].pos.x.toFixed(0) < stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].pos.x.toFixed(0)+1 && stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].pos.y.toFixed(0)-1 < lines[i].vehicles[j].pos.y.toFixed(0) && lines[i].vehicles[j].pos.y.toFixed(0) < stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].pos.y.toFixed(0)+1){
								if(stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].startTime == undefined) {
									stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].startTime = totalTime;
								}
								stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k].boarding = false;
								lines[i].vehicles[j].citizens.push(stations[lines[i].vehicles[j].stoppedID].citizenDeparture[k]);
								stations[lines[i].vehicles[j].stoppedID].citizenDeparture.splice(k, 1);
								lines[i].vehicles[j].hosting += 1;
								if(lines[i].vehicles[j].previousBoarded-1 < lines[i].vehicles[j].hosting) {
									lines[i].vehicles[j].inTransit = true;
									lines[i].vehicles[j].stationBoarded = true;
									lines[i].vehicles[j].boarding = false;
									stations[lines[i].vehicles[j].stoppedID].arrival = false;
								}
							}
							if(lines[i].vehicles[j].previousBoarded-1 < lines[i].vehicles[j].hosting) {
									lines[i].vehicles[j].inTransit = true;
									lines[i].vehicles[j].stationBoarded = true;
									lines[i].vehicles[j].boarding = false;
									stations[lines[i].vehicles[j].stoppedID].arrival = false;
							}
								
						}			
					}
				} else {
					lines[i].vehicles[j].inTransit = true;
					stations[lines[i].vehicles[j].stoppedID].arrival = false;
				}
			}
		}
	}
}