class Camera {
	constructor(canvas) {

		// Initialize variables
		this.name = "Camera";

		// Size
		var baseScreenHeight = 939;
		this.actualSize = 35;
		
		// World and Client position
		this.pos = new Vector(1, 1);
		// Speed
		this.speed = 20/rectHeightRel*1.8;
		this.arenaSize = 2000;
	}
	move(input, deltaTime) {
		this.speed = 20/rectHeightRel*1.8;
		this.size = this.actualSize * rectHeightRel

		if (play == 1) {
			var direction = new Vector(0, 0);
			for (var a in input) {
				switch (input[a]) {
					case 65: // left
						if(this.pos.x > -this.arenaSize) {
							direction.x -= 1;
						}
						break;
					case 87: // up
						if(-this.pos.y > -this.arenaSize) {
							direction.y += 1;
						}
						break;
					case 68: // right
						if(this.pos.x < this.arenaSize) { 
							direction.x += 1;
						}
						break;
					case 83: // down
						if(this.pos.y < this.arenaSize) { 
							direction.y -= 1;
						}
						break;
				}
			}

			direction.normalize();
			direction.mult(this.speed / (averageFps) * 10);
			this.pos.x += direction.x;
			this.pos.y -= direction.y;
		}
	}
	updateRatio(ratio) {
		this.size = 50 * ratio;
	}
}
