var selectedItem = undefined;
var selectedType = undefined;

function drawUI() {
	drawStats();
	drawLineSelect();
	drawBankBalance();
	drawInformation();
	drawRating();
}

function drawRating() {

	ctx.beginPath();
	ctx.globalAlpha = 0.2;
	ctx.fillStyle = 'black';
	ctx.fillRect(canvas.width-200, 0, canvas.width, canvas.height);
	ctx.globalAlpha = 1;
	ctx.closePath();

	var ratingComb = ratings[0] + ratings[1] + ratings[2] + ratings[3] + ratings[4];

	averageRating = (5*ratings[0] + 4*ratings[1] + 3*ratings[2] + 2*ratings[3] + 1*ratings[4])/ratingComb;

	var ratingPerc = [ratings[0]/ratingComb, ratings[1]/ratingComb, ratings[2]/ratingComb, ratings[3]/ratingComb, ratings[4]/ratingComb]

	var rating20list = [0, 0, 0, 0, 0]
	for (var i = 0; i < rating20.length; i++) {
		if(rating20[i] == 5) {
			rating20list[0] += 1;
		} else if(rating20[i] == 4) {
			rating20list[1] += 1;
		} else if(rating20[i] == 3) {
			rating20list[2] += 1;
		} else if(rating20[i] == 2) {
			rating20list[3] += 1;
		} else if(rating20[i] == 1) {
			rating20list[4] += 1;
		}
	}

	var rating20Perc = [rating20list[0]/rating20.length, rating20list[1]/rating20.length, rating20list[2]/rating20.length, rating20list[3]/rating20.length, rating20list[4]/rating20.length];

	//20

	ctx.beginPath();	
	ctx.save();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 250, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 240);
	ctx.arc(canvas.width - 100, canvas.height - 240, 60, 2*Math.PI*0, 2*Math.PI*rating20Perc[0]);
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 200, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 240);
	ctx.arc(canvas.width - 100, canvas.height - 240, 60, 2*Math.PI*(rating20Perc[0]), 2*Math.PI*(rating20Perc[0] + rating20Perc[1]));
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 150, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 240);
	ctx.arc(canvas.width - 100, canvas.height - 240, 60, 2*Math.PI*(rating20Perc[0] + rating20Perc[1]), 2*Math.PI*(rating20Perc[0] + rating20Perc[1] + rating20Perc[2]));
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 100, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 240);
	ctx.arc(canvas.width - 100, canvas.height - 240, 60, 2*Math.PI*(rating20Perc[0] + rating20Perc[1] + rating20Perc[2]), 2*Math.PI*(rating20Perc[0] + rating20Perc[1] + rating20Perc[2] + rating20Perc[3]));
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 50, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 240);
	ctx.arc(canvas.width - 100, canvas.height - 240, 60, 2*Math.PI*(rating20Perc[0] + rating20Perc[1] + rating20Perc[2] + rating20Perc[3]), 2*Math.PI*(rating20Perc[0] + rating20Perc[1] + rating20Perc[2] + rating20Perc[3] + rating20Perc[4]));
	ctx.fill();
	ctx.closePath();
	ctx.restore();
	ctx.closePath();



	//Total
	ctx.beginPath();	
	ctx.save();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 250, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 100);
	ctx.arc(canvas.width - 100, canvas.height - 100, 60, 2*Math.PI*0, 2*Math.PI*ratingPerc[0]);
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 200, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 100);
	ctx.arc(canvas.width - 100, canvas.height - 100, 60, 2*Math.PI*(ratingPerc[0]), 2*Math.PI*(ratingPerc[0] + ratingPerc[1]));
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 150, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 100);
	ctx.arc(canvas.width - 100, canvas.height - 100, 60, 2*Math.PI*(ratingPerc[0] + ratingPerc[1]), 2*Math.PI*(ratingPerc[0] + ratingPerc[1] + ratingPerc[2]));
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 100, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 100);
	ctx.arc(canvas.width - 100, canvas.height - 100, 60, 2*Math.PI*(ratingPerc[0] + ratingPerc[1] + ratingPerc[2]), 2*Math.PI*(ratingPerc[0] + ratingPerc[1] + ratingPerc[2] + ratingPerc[3]));
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'rgb(0, 50, 0)';
	ctx.moveTo(canvas.width - 100, canvas.height - 100);
	ctx.arc(canvas.width - 100, canvas.height - 100, 60, 2*Math.PI*(ratingPerc[0] + ratingPerc[1] + ratingPerc[2] + ratingPerc[3]), 2*Math.PI*(ratingPerc[0] + ratingPerc[1] + ratingPerc[2] + ratingPerc[3] + ratingPerc[4]));
	ctx.fill();
	ctx.closePath();
	ctx.restore();
	ctx.closePath();
	ctx.beginPath();
	ctx.globalAlpha = 1;
	ctx.fillStyle = 'black'
	ctx.font = "15px manrope bold";
	ctx.textAlign = "center"; 
	ctx.fillText('Average Rating: ' + averageRating.toFixed(2), canvas.width - 100, canvas.height - 15);
	ctx.closePath();

}

function drawInformation() {
	var foundItem = false;
	var infoWidth = 350;
	var infoHeight = 200;
	var world = new Vector(((Math.ceil(((mouse.x-canvas.width/2)/rectHeightRel+camera.pos.x)))), ((Math.ceil(((mouse.y-canvas.height/2)/rectHeightRel+camera.pos.y)))));
	if(mouseDown && !placeMode) {
		for (var i = 0; i < stations.length; i++) {
			for (var j = 0; j < stations[i].citizenDeparture.length; j++) {
				if(world.x-(4) < stations[i].citizenDeparture[j].pos.x && stations[i].citizenDeparture[j].pos.x < world.x+(4) && world.y-(4) < stations[i].citizenDeparture[j].pos.y && stations[i].citizenDeparture[j].pos.y < world.y+(4)) {
					selectedItem = stations[i].citizenDeparture[j];
					selectedType = 'citizen';
					foundItem = true;
				} 
			}
			if(!foundItem) {
				if(world.x-(25) < stations[i].pos.x+25 && stations[i].pos.x+25 < world.x+(25) && world.y-(25/2) < stations[i].pos.y+(25/2) && stations[i].pos.y+(25/2) < world.y+(25/2)) {
					selectedItem = stations[i];
					selectedType = 'station';
					foundItem = true;
				}
			}
		}
		if(!foundItem) {
			selectedItem = undefined;
			selectedType = undefined;
		}
	}

	if(selectedItem != undefined) {
		ctx.beginPath();
		ctx.globalAlpha = 0.4;
		fillRoundedRect(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel - infoWidth/2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - infoHeight - 25, infoWidth, infoHeight, 5);
		ctx.closePath();
		ctx.beginPath();
		ctx.moveTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel - 7, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel -25);
		ctx.lineTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + 7, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 25);
		ctx.lineTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 25 + 7);
		ctx.fill();
		ctx.closePath();

		if(selectedType == 'citizen') {
			ctx.beginPath();
			ctx.globalAlpha = 1;
			ctx.fillStyle = 'white'
			ctx.textAlign = "center";
			ctx.font = "30px manrope bold";
			ctx.fillText(selectedItem.name, selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 185, infoWidth - 20);
			ctx.font = "13px manrope medium";
			ctx.fillText(selectedItem.id, selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 165, infoWidth - 20);
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = 1;
			ctx.strokeStyle = 'white';
			ctx.moveTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel - (infoWidth - 20) / 2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 155);
			ctx.lineTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (infoWidth - 20) / 2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 155);
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = 1;
			ctx.strokeStyle = 'white';
			ctx.moveTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + infoWidth / 5, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 155);
			ctx.lineTo(selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + infoWidth / 5, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 40);
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.font = "13px manrope regular";
			ctx.textAlign = "left";
			ctx.textBaseline = "top"; 
			ctx.fillText('Boarding: ' + selectedItem.boarding, selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel - (infoWidth - 20) / 2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 145, infoWidth - 20);
			ctx.fillText('Destination: ' + selectedItem.objectiveName, selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel - (infoWidth - 20) / 2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 128, infoWidth - 20);
			ctx.textAlign = "center";
			ctx.fillText('Travel Time:', selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + ((infoWidth / 5) * 3.5)/2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 145);
			ctx.font = "20px manrope regular";
			if(selectedItem.startTime == undefined) {
				ctx.fillText('0.0', selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + ((infoWidth / 5) * 3.5)/2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 125);
			} else if(selectedItem.endTime == undefined) { 
				ctx.fillText(((totalTime - selectedItem.startTime)/60).toFixed(1), selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + ((infoWidth / 5) * 3.5)/2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 125);
			} else {
				ctx.fillText(((selectedItem.endTime - selectedItem.startTime)/60).toFixed(1), selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + ((infoWidth / 5) * 3.5)/2, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 125);
			}
			ctx.textBaseline = "alphabetic"; 
			ctx.closePath();
		} else if(selectedType == 'station') {
			ctx.beginPath();
			ctx.globalAlpha = 1;
			ctx.fillStyle = 'white'
			ctx.textAlign = "center";
			ctx.font = "30px manrope bold";
			ctx.fillText(selectedItem.name, selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 185, infoWidth - 20);
			ctx.font = "13px manrope medium";
			ctx.fillText(selectedItem.id, selectedItem.pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, selectedItem.pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel - 165, infoWidth - 20);
			ctx.closePath();
		}
	}
}

function drawBankBalance() {
	ctx.beginPath();
	ctx.fillStyle = 'black';
	ctx.globalAlpha = 1;
	ctx.font = "40px manrope medium";
	ctx.textAlign = "right"; 
	ctx.beginPath();
	ctx.fillText('$' + bankBalance, canvas.width - 15, 50);

}

function drawLineSelect() {
	ctx.beginPath();
	ctx.globalAlpha = 0.5;
	fillRoundedRect(15, canvas.height - 65, 50, 50, 5);
	fillRoundedRect(15, canvas.height - 125, 50, 50, 5);
	fillRoundedRect(15, canvas.height - 185, 50, 50, 5);
	fillRoundedRect(15, canvas.height - 245, 50, 50, 5);
	fillRoundedRect(15, canvas.height - 305, 50, 50, 5);
	ctx.closePath();

	ctx.beginPath();
	ctx.fillStyle = 'yellow';
	ctx.arc(15+25, canvas.height-65+25, 15, 0, 2 * Math.PI);
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'purple';
	ctx.arc(15+25, canvas.height-125+25, 15, 0, 2 * Math.PI);
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'orange';
	ctx.arc(15+25, canvas.height-185+25, 15, 0, 2 * Math.PI);
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'blue';
	ctx.arc(15+25, canvas.height-245+25, 15, 0, 2 * Math.PI);
	ctx.fill();
	ctx.closePath();
	ctx.beginPath();
	ctx.fillStyle = 'green';
	ctx.arc(15+25, canvas.height-305+25, 15, 0, 2 * Math.PI);
	ctx.fill();
	ctx.closePath();
}

function drawStats() {

	var lineSpacing = 24;

	var citizensDeparting = 0;
	var citizensArriving = 0;
	var citizensBus = 0;
	for (var i = 0; i < stations.length; i++) {
		citizensDeparting += stations[i].citizenDeparture.length;
		citizensArriving += stations[i].citizenArrival.length;

	}
	if(lines.length > 0) {
		for (var i = 0; i < lines.length; i++) {
			for (var j = 0; j < lines[i].vehicles.length; j++) {
			citizensBus += lines[i].vehicles[j].citizens.length;
			}
		}
	}

	ctx.beginPath();
	ctx.fillStyle = 'black';
	ctx.globalAlpha = 1;
	ctx.font = "16px manrope regular";
	ctx.textAlign = "left"; 
	ctx.fillText('FPS: ' + averageFps.toFixed(2), 10, lineSpacing);
	ctx.fillText('Stations: ' + stations.length, 10, lineSpacing*2);
	ctx.fillText('Citizens: ' + (citizensDeparting + citizensBus + citizensArriving), 10, lineSpacing*3);
	ctx.fillText('Arrving: ' + citizensArriving, 25, lineSpacing*4);
	ctx.fillText('Departing: ' + citizensDeparting, 25, lineSpacing*5);
	ctx.fillText('Enroute: ' + citizensBus, 25, lineSpacing*6);
	ctx.fillText('Routes:', 10, lineSpacing*7);
	ctx.fillText('Bus: ' + lines.length, 25, lineSpacing*8);
	ctx.fillText('Metro: 0', 25, lineSpacing*9);
	ctx.fillText('Train: 0', 25, lineSpacing*10);
	ctx.fillText('Streetcar: 0', 25, lineSpacing*11);
	ctx.fillText('Cycle: ' + cycleCount.toFixed(3), 10, lineSpacing*12);
	ctx.fillText('Time Elapsed: ' + totalTime.toFixed(1), 10, lineSpacing*13);
	ctx.closePath()
}

function fillRoundedRect(x, y, w, h, r){
	// Draw rounded rectangle
    ctx.beginPath();
    ctx.moveTo(x+r, y);
    ctx.lineTo(x+w-r, y);
    ctx.quadraticCurveTo(x+w, y, x+w, y+r);
    ctx.lineTo(x+w, y+h-r);
    ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
    ctx.lineTo(x+r, y+h);
    ctx.quadraticCurveTo(x, y+h, x, y+h-r);
    ctx.lineTo(x, y+r);
    ctx.quadraticCurveTo(x, y, x+r, y);
    ctx.fill();   
}