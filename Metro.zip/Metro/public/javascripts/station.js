class Station {
	constructor(pos, type, system) {

		this.id = randomString(15);
		this.name = stationNames[Math.floor(Math.random() * stationNames.length)] + ' Station';

		//Type setup
		this.pos = pos;
		this.stationType = type;
		this.system = system;

		//Station stats
		this.citizenArrival = [];
		this.citizenDeparture = [];
		this.waiting = this.citizenDeparture.length;
		this.hosted = 0;

		this.connections = [];

		this.arrival = false;

	}
}

var spawnRadius = 500;
function stationUpdate() {
	for (var i = 0; i < stations.length; i++) {
		stations[i].waiting = stations[i].citizenDeparture.length;
		for (var j = 0; j < stations[i].citizenDeparture.length; j++) {
			if(!stations[i].arrival) {
					stations[i].citizenDeparture[j].boarding = false;
			}
			if(!stations[i].citizenDeparture[j].boarding) {
				if(Math.floor(j/4)%2 == 0) {
					stations[i].citizenDeparture[j].target = new Vector(12 + stations[i].pos.x + (10*(j-(4*(Math.floor(j/4))))), (stations[i].pos.y + 15) - (10*(Math.floor(j/4))));
				} else {
					stations[i].citizenDeparture[j].target = new Vector(42 + stations[i].pos.x - (10*(j-(4*(Math.floor(j/4))))), (stations[i].pos.y + 15) - (10*(Math.floor(j/4))));
				}
			}
		}
	}
}

/*setInterval(function() {
	if(Math.floor(Math.random() * 10) == 1) {
		if(spawnRadius != arenaSize) {
			spawnRadius += 50;
		}

		var newSpawn = randomSpawnPos();
		stations.push(new Station(newSpawn, 'bus', 'citizen'));
	}
}, 1000)*/

function randomSpawnPos() {
	var randomSpawn = new Vector(Math.floor(Math.random() * spawnRadius/25)*25, Math.floor(Math.random() * spawnRadius/25)*25);
	if(Math.floor(Math.random() * 2) == 1) {
		randomSpawn.x = -randomSpawn.x;
	}
	if(Math.floor(Math.random() * 2) == 1) {
		randomSpawn.y = -randomSpawn.y;
	}
	return randomSpawn;
}

