// Keyboard input (advanced)
var rawInput = [];
var eventInput = {};
$("body").keydown(function (e) {
	// Raw input
	var flag = true;
	for (var i in rawInput) {
		if (e.keyCode === rawInput[i]) {
			flag = false;
		}
	}
	if (flag) {
		rawInput.push(e.keyCode);
	}

	// Event input
	if (!eventInput[e.keyCode]) {
		eventInput[e.keyCode] = true;
	}
	if (e.keyCode === 9) {
		e.preventDefault();
	}
})
$("body").keyup(function (e) {
	// Raw input
	for (var i = 0; i < rawInput.length; i++) {
		if (e.keyCode === rawInput[i]) {
			rawInput.splice(i,1);
		}
	}
	// Event input
	eventInput[e.keyCode] = false;
})

var mouse = new Vector();
var click = true;
// Mousemove event
$("#canvas").mousemove(function (e) {
	mouse.x = e.offsetX;
	mouse.y = e.offsetY;
})

// Click event

var mouseDown = false;
var middleDown = false;
var rightDown = false;
$("#canvas").mousedown(function (e) {
	if (e.button === 0) {
		mouseDown = true;
	} else if (e.button === 1) {
		middleDown = true;
	} else if (e.button === 2) {
		rightDown = true;
	}
	
	e.preventDefault();
}).mouseup(function (e) {
	if (e.button === 0) {
		mouseDown = false;
	} else if (e.button === 1) {
		middleDown = false;
	} else if (e.button === 2) {
		rightDown = false;
	}
	// Reset click events
	click = false;
})

// Prevent right click
$("body").on('contextmenu', function(e) {
	e.preventDefault();
})

// Scroll event
var scrollSpeed = 0.05;
$(window).bind('mousewheel', function(event) {
	if (play != 0 && play != 3) {
		if (event.originalEvent.wheelDelta >= 0 && rectHeightRel < 5) {
	        rectHeightRel += scrollSpeed;
	    } else if (event.originalEvent.wheelDelta >= 0) {
	    	rectHeightRel = 5;
	    } else if (rectHeightRel > 0.3) {
	        rectHeightRel -= scrollSpeed;
	    }
	    camera.updateRatio(rectHeightRel);
	}  
});

// Resize event
$(window).resize(function () {
	canvas.width = $(window).innerWidth()
	canvas.height = $(window).innerHeight();
	rectHeightRel = canvas.height / baseScreenHeight;
	relativeHeight = rectHeightRel;
})

