// Game loop draw function
function draw() {

	ctx.clearRect(0, 0, canvas.width, canvas.height)

	drawGrid();
	drawStation();
	drawCitizens();
	linePlace();
	drawLines();
	drawVehicle();
	drawUI();

}

function drawVehicle() {
	for (var i = 0; i < lines.length; i++) {
		for (var j = 0; j < lines[i].vehicles.length; j++) {
			ctx.beginPath();
			ctx.globalAlpha = 1;
			ctx.save();
			ctx.translate((lines[i].vehicles[j].pos.x+25/2)*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, (lines[i].vehicles[j].pos.y+25/2)*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel)
			ctx.rotate(lines[i].vehicles[j].rotation);
			ctx.fillStyle = 'rgb(0,' + (50+(3*lines[i].vehicles[j].hosting)) + ', 0)';
			ctx.fillRect(-(50/2)*rectHeightRel, -(17/2)*rectHeightRel, 50*rectHeightRel, 17*rectHeightRel);
			ctx.restore();
			ctx.closePath();
		}	
	}
}

function drawLines() {
	for (var i = 0; i < lines.length; i++) {
		ctx.beginPath();
		ctx.lineCap = "round";
		ctx.lineWidth = 7*rectHeightRel;
		ctx.fillStyle = 'green';
		ctx.globalAlpha = 0.5;
		ctx.moveTo(lines[i].linePath[0].x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (25/2)*rectHeightRel, lines[i].linePath[0].y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + (25/2)*rectHeightRel);
		for (var j = 1; j < lines[i].linePath.length; j++) {
			ctx.lineTo(lines[i].linePath[j].x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (25/2)*rectHeightRel, lines[i].linePath[j].y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + (25/2)*rectHeightRel);
		}
		ctx.lineTo(lines[i].linePath[0].x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (25/2)*rectHeightRel, lines[i].linePath[0].y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + (25/2)*rectHeightRel);
		ctx.stroke();
		ctx.closePath();
		

	}
}

function drawStation() {

	
	for (var i = 0; i < stations.length; i++) {
		ctx.beginPath();
		ctx.lineWidth = 5*rectHeightRel;
		ctx.lineCap = "butt";
		ctx.globalAlpha = 1;
		ctx.strokeStyle = 'green';
		ctx.moveTo(stations[i].pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (5/2)*rectHeightRel, stations[i].pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel);
		ctx.lineTo(stations[i].pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (5/2)*rectHeightRel, stations[i].pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + 25*rectHeightRel - (5/2)*rectHeightRel);
		ctx.lineTo(stations[i].pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel + (50)*rectHeightRel, stations[i].pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel + 25*rectHeightRel - (5/2)*rectHeightRel);
		ctx.stroke();
		ctx.closePath();
	}
}

function drawCitizens() {
	
	for (var i = 0; i < stations.length; i++) {
		for (var j = 0; j < stations[i].citizenDeparture.length; j++) {
			ctx.beginPath();
			ctx.globalAlpha = stations[i].citizenDeparture[j].opacity;
			if(stations[i].citizenDeparture[j].opacity < 1) {
				stations[i].citizenDeparture[j].opacity += 0.02;
			} else {
				stations[i].citizenDeparture[j].opacity = 1;
			}
			ctx.fillStyle = 'black';
			ctx.arc(stations[i].citizenDeparture[j].pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, stations[i].citizenDeparture[j].pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel, 4*rectHeightRel, 0, 2 * Math.PI);
			ctx.fill();
			ctx.globalAlpha = 1;
			ctx.closePath();
			ctx.beginPath();
			ctx.globalAlpha = 1;
			ctx.font = "12px manrope regular";
			ctx.textAlign = "center"; 
			ctx.beginPath();
		}
	}
	for (var i = 0; i < stations.length; i++) {
		for (var k = 0; k < stations[i].citizenArrival.length; k++) {
			ctx.beginPath();
			if(stations[i].citizenArrival[k].arrived) {
				ctx.globalAlpha = stations[i].citizenArrival[k].opacity;
			} else {
				ctx.globalAlpha = 0;
			}
			ctx.fillStyle = 'grey';
			ctx.arc(stations[i].citizenArrival[k].pos.x*rectHeightRel+canvas.width/2-camera.pos.x*rectHeightRel, stations[i].citizenArrival[k].pos.y*rectHeightRel+canvas.height/2-camera.pos.y*rectHeightRel, 4*rectHeightRel, 0, 2 * Math.PI);
			ctx.fill();
			ctx.globalAlpha = 1;
			ctx.closePath();
			ctx.beginPath();
			ctx.globalAlpha = 1;
			ctx.font = "12px manrope regular";
			ctx.textAlign = "center";
		}
	}

}

function drawGrid() {

	ctx.lineWidth = 0.1;
	ctx.globalAlpha = 1 * (rectHeightRel / 0.9);
	ctx.strokeStyle = 'black';

	// Create grid offset from drawing when zooming
	ctx.beginPath();
	var rightOffset = -camera.pos.x*rectHeightRel%(25*rectHeightRel)/(25*rectHeightRel)
	for (var x = rightOffset+1; x < canvas.width/(25*rectHeightRel); x++) {
		ctx.moveTo(x*(25*rectHeightRel)+canvas.width/2, 0);
		ctx.lineTo(x*(25*rectHeightRel)+canvas.width/2, canvas.height);
	}
	var leftOffset = camera.pos.x*rectHeightRel%(25*rectHeightRel)/(25*rectHeightRel)
	for (var x = leftOffset; x < canvas.width/(25*rectHeightRel); x++) {
		ctx.moveTo(x*-(25*rectHeightRel)+canvas.width/2, 0);
		ctx.lineTo(x*-(25*rectHeightRel)+canvas.width/2, canvas.height);
	}
	var bottomOffset = -camera.pos.y*rectHeightRel%(25*rectHeightRel)/(25*rectHeightRel);
	for (var y = bottomOffset+1; y < canvas.height/(25*rectHeightRel); y++) {
		ctx.moveTo(0, y*(25*rectHeightRel)+canvas.height/2);
		ctx.lineTo(canvas.width, y*(25*rectHeightRel)+canvas.height/2);
	}
	var topOffset = camera.pos.y*rectHeightRel%(25*rectHeightRel)/(25*rectHeightRel);
	for (var y = topOffset; y < canvas.height/(25*rectHeightRel); y++) {
		ctx.moveTo(0, y*-(25*rectHeightRel)+canvas.height/2);
		ctx.lineTo(canvas.width, y*-(25*rectHeightRel)+canvas.height/2);
	}
	ctx.stroke();
	ctx.closePath();

	// Reset Alpha
	ctx.globalAlpha = 1;

	// Draw map boundaries
	ctx.beginPath();
	ctx.strokeStyle = "black"
	ctx.lineWidth = 2;
	ctx.moveTo(-arenaSize*rectHeightRel-camera.pos.x*rectHeightRel+canvas.width/2, -arenaSize*rectHeightRel-camera.pos.y*rectHeightRel+canvas.height/2);
	ctx.lineTo(-arenaSize*rectHeightRel-camera.pos.x*rectHeightRel+canvas.width/2, arenaSize*rectHeightRel-camera.pos.y*rectHeightRel+canvas.height/2);
	ctx.lineTo(arenaSize*rectHeightRel-camera.pos.x*rectHeightRel+canvas.width/2, arenaSize*rectHeightRel-camera.pos.y*rectHeightRel+canvas.height/2);
	ctx.lineTo(arenaSize*rectHeightRel-camera.pos.x*rectHeightRel+canvas.width/2, -arenaSize*rectHeightRel-camera.pos.y*rectHeightRel+canvas.height/2);
	ctx.lineTo(-arenaSize*rectHeightRel-camera.pos.x*rectHeightRel+canvas.width/2, -arenaSize*rectHeightRel-camera.pos.y*rectHeightRel+canvas.height/2);
	ctx.stroke();
	ctx.closePath();

}

function inScreen(x, y, player) {

	//If player in spectator mode return true
	if(play === 3) {
		return true;
	} else {

		//Make sure the coordintes of the player and the factor are within the screen size
		if ((x - player.pos.x + player.actualSize) * rectHeightRel < canvas.width * rectHeightRel && (x - player.pos.x - player.actualSize) * rectHeightRel > -canvas.width * rectHeightRel && (y - player.pos.y + player.actualSize) * rectHeightRel < canvas.height * rectHeightRel && (y - player.pos.y - player.actualSize) * rectHeightRel > -canvas.height * rectHeightRel) {
			return true;
		}
	}
}