var express = require('express');
var app = express();
var https = require('https');
var fs = require('fs');
var options = {
	key: fs.readFileSync('./ia.key'),
	cert: fs.readFileSync('./server.crt'),
	ca: fs.readFileSync('./ca.crt')
}
var server = https.createServer(options, app);
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var readline = require('readline');
var fs = require('fs');
var io = require('socket.io')(server);
var util = require('util');

//Create port
server.listen(443, function () {
	console.log('Started an https server on port 443.');
})
var public = __dirname + '/public/';

//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
//app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/*', function (req, res, next) {
	res.redirect('/')
	next()
})

// Server input commands

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Commmand line input
rl.on('line', (input) => {
  	if (input === 'refresh') {
  		io.emit('refresh');
  	} else if (input.split(" ")[0] === "ban") {
  		console.log(input.split(" ")[1])
  	}
});

// Server-client connection architecture
io.on('connect', function(socket) { 
	console.log('IP: ' + socket.request.connection.remoteAddress.replace('::ffff:', '') + ' | ID: ' + socket.id + ' connected to on ' + Date())
	// Update ip
	var banned = false;

	// Check if player is banned
	fs.readFile('./ip.json', function (err, data) {
		var ips = JSON.parse(data);
		var ip = socket.request.connection.remoteAddress.replace('::ffff:', '')

		for (var i = 0; i < ips.black.length; i++) {
			if (ip === ips.black[i]) {
				banned = true;
				socket.emit('banned')
			}
		}
	});

	// Client player
	var player = undefined;
	var rawInput = [];

	socket.on('join', function (data) {
		if (!banned) {
			// Check if the player already exists
			var exists = false;
			for (var i = 0; i < lobby.length; i++) {
				if (socket.id === lobby[i].id) {
					exists = true;
				}
			}

			if (!exists) {
				// Join the lobby
				data.id = socket.id;
				player = data;
				player.pos = new Vector(data.pos.x,data.pos.y);
				lobby.push(player);

			}

			console.log(data.name + " with id " + socket.id.slice(0, 5) + "... at " + Date() + " spawned.")
		}
	})

	// Receive player input and update the client
	var delta = 16;
	var then = Date.now();
	var now = Date.now();
	var prev = Date.now();
	// Disconnect
	socket.on('disconnect', function () {
		console.log(socket.id + " left at "  + Date())
	});
});

setInterval(function () {
	// Send all player data to everyone
}, 100);

module.exports = app;